# nodets-canil
Projeto feito no módulo do curso Node + Typescrip
# Pré-requisito
`npm i -g nodemon typescript ts-node`

# Instalação
`npm install`
# Para rodar o projeto
`npm run start-dev`
